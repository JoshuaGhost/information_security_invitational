/*
 * Cheops Next Generation GUI
 * 
 * agent-auth.c
 * This file contains all of the authentication code contained in the agent
 * the authentication process contains a trap door: the host can not login 
 * immediatly agter a unsuccessfull login, they have to wait for 10 secs for
 * another logon attempt
 *
 * Copyright(C) 1999 Brent Priddy <toopriddy@mailcity.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *                                                                  
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA
 */

#ifndef _AGENT_AUTH_H
#define _AGENT_AUTH_H

#include "event.h"

char *make_rand_string(void);

int send_auth_challange(agent *a);

int handle_auth_request(event_hdr *h, event *e, agent *a);
int handle_auth_ask(event_hdr *h, event *e, agent *a);


#endif /* _AGENT_AUTH_H */


