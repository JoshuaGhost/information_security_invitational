/*
 *	data struct old edition
 *	Chapter 8 stack and queue 
 *	author:Zhang Zijian
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 */

#include<stdio.h>
#include<string.h>

void push (int *queue, int *rear, int *quelen, const int n)
{
	(*rear)++;
	(*quelen)++;
	queue[*rear % 10]=n;
	printf("action push\n");
	printf("rear:%d; quelen:%d; element:%d;\n", 
		*rear, 
		*quelen, 
		queue[(*rear) % 10]);

}

void pop (int *queue, int *rear, int *quelen)
{
	printf("acrtion pop\n");
	printf("rear:%d; quelen:%d; element:%d;\n", 
		*rear, 
		(*quelen)-1, 
		queue[(*rear-*quelen+1) % 10]);
	queue[((*rear)-(*quelen)+1) % 10]=0;
	(*quelen)--;
}

int main(int argc, char **argv)
{
	int rear=9,quelen=0,i,j;
	int a[10];
	memset(a, 0, sizeof(a));
	for (i=0; i<20; i++){
		if (quelen>9)
			for(j=0; j<3; j++){
				pop(a,&rear,&quelen);
			}
		push(a,&rear,&quelen,i);
	}
	return 0;
}
