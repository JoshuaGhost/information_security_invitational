/*
 *	data struct old edition
 *	Chapter 10 graph 
 *	author:Zhang Zijian
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 */

#define MAXN 4

int a[MAXN][MAXN];
int anc(int *f, int n)
{
	if (f[n]==n)
		return n;
	return anc(f, f[n]);
}

void disj(int *f)
{
	int sum=0;
	int i, j, ai ,aj;
	for (i=0; i<MAXN; i++)
		f[i]=i;
	for (i=0; i<MAXN; i++)
		for(j=0; j<MAXN; j++)
			if (a[i][j]){
				ai=anc(f,i);
				aj=anc(f,j);
				if (ai!=aj)
					f[i]=aj;
			}
}

void kruskal()
{
	int i, j, k;
	for (k=0; k<=MAXN; k++)
		for (i=0; i<=MAXN; i++)
			for(j=0; j<=MAXN; j++)
				a[i][j]=(a[i][k] && a[k][j])?1:a[i][j];
}

int main(int argc, char **argv)
{
	int f[MAXN], b[MAXN], m, i, j, x, y, ai, sum;
	/*
	 *inputation and intialization
	 */
	printf("Please input the information of the graph.\n");
	scanf("%d", &m);
	memset(a, 0, sizeof(a));
	for (i=0; i<MAXN; i++) a[i][i]=1;
	for (i=0; i<m; i++){
		scanf("%d%d", &x, &y);
		a[y][x]=1;
		a[x][y]=1;
	}
	/*
	 *show the adjacency matrix
	 */
	printf ("The adjacency matrix is like this:\n");
	for (i=0; i<MAXN; i++){
		for(j=0; j<MAXN; j++)
			printf("%d  ",a[i][j]);
		printf("\n");
	}
	/*
	 *make the reachability matrix
	 */
	kruskal();
	printf ("The reachability matrix is like this:\n");
	for (i=0; i<MAXN; i++){
		for(j=0; j<MAXN; j++)
			printf("%d  ",a[i][j]);
		printf("\n");
	}
	/*
	 *make disjoint set
	 */
	disj(f);
	/*
	 *the two vertexes is in one connected subgraph when they have a 
	 *common ancestor in the disjoint set
	 */
	for (i=0; i<MAXN; i++)
		b[i]=0;
	for (i=0; i<MAXN; i++){
		ai=anc(f,i);
		if (!b[ai]){
			b[ai]=1;
			sum++;
		}
	}
	printf("The quantity of connected component is :%d", sum);
	return 0;
}
