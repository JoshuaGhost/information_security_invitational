/*
 *	data struct old edition
 *	Chapter 6 linear list
 *	author:Zhang Zijian
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 */

#include<stdio.h>
#include<stdlib.h>

typedef struct com{
	/* 
	 * Comlex linear list which contain 3 types of data
	 */
	char mem_int,mem_char,mem_oth;
	struct com *next;
};

typedef struct sep{
	/*
	 * Seprated linear loop list each of wich contains only 1 type of data
	 */
	char *mem;
	struct sep *next, *prev;
};

int main(int argc, char **argv)
{
	int i;
	struct com *p_com, *src_head;
	struct sep *p_sep, *obj_int_head, *obj_char_head, *obj_oth_head;
	src_head=(struct com *)malloc(sizeof(struct com));
	p_com = src_head;
	p_com->mem_int = 48;
	p_com->mem_char = 97;
	p_com->mem_oth = 'Z'+1;
	for (i=1;i<10;i++){
		p_com->next = malloc(sizeof(struct com));
		p_com = p_com->next;
		p_com->mem_int=48+i;
		p_com->mem_char = 97+i;
		p_com->mem_oth = 'Z'+1+i;
	}
	p_com->next=NULL;

	printf("complex types linear list:\n");
	p_com = src_head;
	for (i=0;i<10;i++){
		printf(".int:%c .char:%c .oth:%c\n", p_com->mem_int, 
						     p_com->mem_char, 
						     p_com->mem_oth);
		p_com=p_com->next;
	}

	/*
	 *obj_int
	 */
	obj_int_head = malloc(sizeof(struct sep));
	p_sep = obj_int_head;
	p_com = src_head;
	p_sep->mem = &(p_com->mem_int);
	while (p_com->next){
		p_sep->next = malloc(sizeof(struct sep));
		p_sep->next->prev=p_sep;
		p_sep = p_sep->next;
		p_com = p_com->next;
		p_sep->mem = &(p_com->mem_int);
	}
	p_sep->next=obj_int_head;
	obj_int_head->prev=p_sep;

	/*
	 *obj_char
	 */
	obj_char_head = malloc(sizeof(struct sep));
	p_sep = obj_char_head;
	p_com = src_head;
	p_sep->mem = &(p_com->mem_char);
	while (p_com->next){
		p_sep->next = malloc(sizeof(struct sep));
		p_sep->next->prev=p_sep;
		p_sep = p_sep->next;
		p_com = p_com->next;
		p_sep->mem = &(p_com->mem_char);
	}
	p_sep->next=obj_char_head;
	obj_char_head->prev=p_sep;

	/*
	 *obj_oth
	 */
	obj_oth_head = malloc(sizeof(struct sep));
	p_sep = obj_oth_head;
	p_com = src_head;
	p_sep->mem = &(p_com->mem_oth);
	while (p_com->next){
		p_sep->next = malloc(sizeof(struct sep));
		p_sep->next->prev=p_sep;
		p_sep = p_sep->next;
		p_com = p_com->next;
		p_sep->mem = &(p_com->mem_oth);
	}
	p_sep->next=obj_oth_head;
	obj_oth_head->prev=p_sep;

	
	printf("---------------------------------------------\n");
	printf("integer linear list:\n");
	p_sep = obj_int_head;
	for (i=0;i<10;i++){
		printf(".mem_int:%c\n", *(p_sep->mem));
		p_sep=p_sep->next;
	}

	printf("---------------------------------------------\n");
	printf("character linear list:\n");
	p_sep = obj_char_head;
	for (i=0;i<10;i++){
		printf(".mem_int:%c\n", *(p_sep->mem));
		p_sep=p_sep->next;
	}

	printf("---------------------------------------------\n");
	printf("other linear list:\n");
	p_sep = obj_oth_head;
	for (i=0;i<10;i++){
		printf(".mem_int:%c\n", *(p_sep->mem));
		p_sep=p_sep->next;
	}

	return 0;
}
