/*
 *	data struct old edition
 *	Chapter 9 tree 
 *	author:Zhang Zijian
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 */

#include<stdio.h>
#include<stdlib.h>

int n;

typedef struct treenode{
	int data;
	struct treenode *left, *right;
};

struct treenode *mk_ful_tree(const int t)
{
	struct treenode *p;
	p=malloc(sizeof(struct treenode));
	p->data=t;
	if (t*2<=n){
		p->left=mk_ful_tree(t*2);
		printf("the left child of node %d is %d.\n",t ,t*2);
		if (t*2+1<=n){
			p->right=mk_ful_tree(t*2+1);
			printf("the right child of node %d is %d.\n",t, t*2+1);
		}else{p->right=0;}
	}else{p->left=0;}
	if (t==1) printf("A complete binary tree has been enstablished\n");
	return p;
}

void del(struct treenode *p)
{
	if (p->left)
		del(p->left);
	if (p->right)
		del(p->right);
	printf("the node %d has been deleted.\n", p->data);
	free(p);
}

int s_remove(struct treenode *p, int x)
{
	const struct treenode *t;
	if (p->right->data==x){
		del(p->right);
		p->right=0;
		return 1;
	}
	if (p->left->data==x){
		del(p->left);
		p->left=0;
		return 1;
	}
	if (p->left)
		if (s_remove(p->left, x))
			return 1;
	if (p->right)
		if (s_remove(p->right, x))
			return 1;
	return 0;
}

int main(int argcm, char **argv)
{
	int x;
	scanf("%d",&n);
	scanf("%d",&x);
	s_remove(mk_ful_tree(1), x);
	printf("The node %x and it's subtree has been removed.\n", x);
	return 0;
}
