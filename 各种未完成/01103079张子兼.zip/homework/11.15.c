/*
 *	data struct old edition
 *	Chapter 11 hash 
 *	author:Zhang Zijian
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 */

#include<stdio.h>
#include<stdlib.h>

int h(int souc)
{
	return ((souc / 10)*13 + (souc % 10)) % 10;
}

int insert(int *a, int b)
{
	int temp=h(b);
	if (a[temp])
		while (a[temp])
			temp=(temp+1) % 10;
	a[temp]=b;
	return temp;
}

int del(int *a, int b)
{
	int temp=h(b);
	while (a[temp]!=b)
		temp = (temp+1) % 10;
	a[temp]=0;
	return temp;
}

int main(int argc, char **argv)
{
	int a[10], i, b[10];
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	for (i=0; i<9; i++){
		scanf("%d",&b[i]);
		printf("You have insert elements %d at a[%d].\n", b[i], insert(a,b[i]));
	}
	printf("Insertation has been finished.\n");
	printf("Element ""%d"" at a[%d] has been deleted.\n", b[3], del(a,b[3]));
	printf("Element ""%d"" at a[%d] has been deleted.\n", b[7], del(a,b[7]));
	return 0;
}
