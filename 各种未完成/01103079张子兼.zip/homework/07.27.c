/*
 *	data struct old edition
 *	Chapter 7 string and array 
 *	author:Zhang Zijian
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 */

#include<stdio.h>
#define maxn 2

int getpos(int xx, int yy)
{
	if (yy>xx) {
		xx=xx^yy;
		yy=xx^yy;
		xx=xx^yy;
	}
	return (xx*(xx+1)/2+yy);
}

int main()
{
	int matrix_a[maxn*(maxn+1)/2], matrix_b[maxn*(maxn+1)/2];
	int res[maxn][maxn];
	int i, j, temp, k;

	for (i=0; i<maxn*(maxn+1)/2; i++){
		scanf("%d",&matrix_a[i]);
	}

	for (i=0; i<maxn*(maxn+1)/2; i++){
		scanf("%d",&matrix_b[i]);
	}

	for (i=0; i<maxn; i++)
		for (j=0; j<maxn; j++){
			temp=0;
			for (k=0; k<maxn; k++){
				temp+=matrix_a[getpos(i,k)]*matrix_b[getpos(k,j)];
			}
			res[i][j]=temp;
		}
	
	for (i=0; i<maxn; i++){
		for (j=0; j<maxn; j++){
			printf("%d  ",res[i][j]);
		}
		printf("\n");
	}

	return 0;
}
